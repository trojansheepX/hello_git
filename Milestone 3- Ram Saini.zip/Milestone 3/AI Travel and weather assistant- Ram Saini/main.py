
import os
import json
import sqlite3

from datetime import date, timedelta
from uuid import UUID, uuid4

import redis
import requests
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, model_validator

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

from init_db import DB_PATH, create_schema


# step 1: load configuration
load_dotenv()

app = FastAPI(title="Travel Weather Advisory API")

SESSION_TTL = 3600  # 1 hour
MAX_HISTORY = 10  # last 5 question and answer pairs
FORECAST_DAYS = 16  # open-meteo forecast horizon including today
HTTP_TIMEOUT = 10

create_schema()


# step 2: connect to redis
db = redis.Redis.from_url(
    os.getenv("REDIS_URL", "redis://localhost:6379/0"),
    decode_responses=True
)


# step 3: connect to the llm through openrouter
llm = ChatOpenAI(
    model=os.getenv("OPENROUTER_MODEL", "nvidia/nemotron-3.5-super-vl:free"),
    api_key=os.environ["OPENROUTER_API_KEY"],
    base_url=os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
    temperature=0
)


# step 4: sqlite helpers
def fetch_trip(trip_id: int):
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("select * from trips where trip_id = ?", (trip_id,)).fetchone()
    return dict(row) if row else None


def fetch_employee_trips(employee_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "select * from trips where employee_id = ? order by start_date",
            (employee_id,)
        ).fetchall()
    return [dict(row) for row in rows]


# step 5: open-meteo helpers
WEATHER_CODES = {
    0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
    45: "fog", 48: "fog", 51: "light drizzle", 53: "drizzle", 55: "heavy drizzle",
    61: "light rain", 63: "rain", 65: "heavy rain", 71: "light snow", 73: "snow",
    75: "heavy snow", 80: "rain showers", 81: "rain showers", 82: "violent rain showers",
    95: "thunderstorm", 96: "thunderstorm with hail", 99: "thunderstorm with hail",
}


def geocode(city: str):
    response = requests.get(
        "https://geocoding-api.open-meteo.com/v1/search",
        params={"name": city, "count": 1, "language": "en", "format": "json"},
        timeout=HTTP_TIMEOUT
    )
    response.raise_for_status()
    results = response.json().get("results") or []
    return results[0] if results else None


def forecast(city: str, start_date: str, end_date: str) -> dict:
    try:
        start = date.fromisoformat(start_date)
        end = date.fromisoformat(end_date)
    except ValueError:
        return {"error": "dates must be in yyyy-mm-dd format"}

    if end < start:
        return {"error": "end date is before start date"}

    today = date.today()
    last_day = today + timedelta(days=FORECAST_DAYS - 1)

    if end < today:
        return {"error": f"trip dates {start} to {end} are in the past, no forecast available"}
    if start > last_day:
        return {"error": f"forecast is only available up to {last_day}, trip starts on {start}. weather data is not available yet"}

    # keep only the part of the trip that is inside the forecast horizon
    from_day = max(start, today)
    to_day = min(end, last_day)
    note = None
    if (from_day, to_day) != (start, end):
        note = f"forecast covers only {from_day} to {to_day}, the rest of the trip is outside the forecast horizon"

    try:
        place = geocode(city)
        if not place:
            return {"error": f"destination '{city}' could not be found"}

        response = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": place["latitude"],
                "longitude": place["longitude"],
                "daily": "weather_code,temperature_2m_max,temperature_2m_min,"
                         "precipitation_sum,precipitation_probability_max",
                "timezone": "auto",
                "start_date": from_day.isoformat(),
                "end_date": to_day.isoformat(),
            },
            timeout=HTTP_TIMEOUT
        )
        response.raise_for_status()
        daily = response.json()["daily"]
    except (requests.RequestException, KeyError, ValueError) as error:
        return {"error": f"weather service unavailable: {error}"}

    days = []
    for i, day in enumerate(daily["time"]):
        # skip days the provider has no data for yet
        if daily["temperature_2m_max"][i] is None:
            continue
        days.append({
            "date": day,
            "condition": WEATHER_CODES.get(daily["weather_code"][i], "unknown"),
            "temp_max_c": daily["temperature_2m_max"][i],
            "temp_min_c": daily["temperature_2m_min"][i],
            "precipitation_mm": daily["precipitation_sum"][i],
            "precipitation_chance_pct": daily["precipitation_probability_max"][i],
        })

    if not days:
        return {"error": f"no forecast data available for {city} between {from_day} and {to_day}"}

    return {
        "location": f"{place['name']}, {place.get('country', '')}".strip(", "),
        "days": days,
        "note": note,
        "source": "open-meteo.com",
    }


# step 6: langchain tools
@tool
def get_trip(trip_id: int) -> str:
    """get a saved trip by its trip id."""
    trip = fetch_trip(trip_id)
    return json.dumps(trip or {"error": f"trip {trip_id} not found"})


@tool
def find_employee_trips(employee_id: str) -> str:
    """list all saved trips for an employee id such as EMP104."""
    trips = fetch_employee_trips(employee_id)
    return json.dumps(trips or {"error": f"no trips found for employee {employee_id}"})


@tool
def get_weather_forecast(city: str, start_date: str, end_date: str) -> str:
    """get the daily weather forecast for a city between start_date and end_date (yyyy-mm-dd)."""
    return json.dumps(forecast(city, start_date, end_date))


TOOLS = {t.name: t for t in [get_trip, find_employee_trips, get_weather_forecast]}

GATHER_PROMPT = """you collect facts for a business travel assistant. today is {today}.
session context: employee_id={employee_id}, trip_id={trip_id}.
always use the tools to get the trip and the weather, never guess them.
first find the relevant trip with get_trip or find_employee_trips, then call get_weather_forecast
with the trip destination and dates. use the conversation history to understand words like 'there'.
if the user asks about a city without a saved trip, call get_weather_forecast with the dates they give.
when you have the facts, reply with the word done."""

ADVICE_PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "you are a business travel advisor. today is {today}. answer only from the facts below and the conversation. "
     "never invent weather. if a fact contains an error or weather is missing, say clearly that the data is not available and why. "
     "keep the answer short: mention the destination, a brief weather summary with temperatures and rain, "
     "then 3-4 packing or travel suggestions. answer the user's actual question directly first."),
    MessagesPlaceholder("history"),
    ("human", "question: {question}\n\nfacts from tools:\n{facts}"),
])

advice_chain = ADVICE_PROMPT | llm | StrOutputParser()


# step 7: stage one, let the model call tools to gather facts
def gather_facts(question: str, history: list, context: dict, session_key: str):
    messages = [
        SystemMessage(GATHER_PROMPT.format(
            today=date.today().isoformat(),
            employee_id=context.get("employee_id", "unknown"),
            trip_id=context.get("trip_id", "unknown"),
        )),
        *history,
        HumanMessage(question),
    ]
    model = llm.bind_tools(list(TOOLS.values()))
    facts, calls = [], []

    for _ in range(5):
        reply = model.invoke(messages)
        messages.append(reply)
        if not reply.tool_calls:
            break

        for call in reply.tool_calls:
            selected = TOOLS.get(call["name"])
            result = selected.invoke(call["args"]) if selected else json.dumps({"error": "unknown tool"})
            messages.append(ToolMessage(result, tool_call_id=call["id"]))
            facts.append(f"{call['name']}({json.dumps(call['args'])}) -> {result}")
            calls.append({"tool": call["name"], "args": call["args"]})

            # remember the trip in the session so follow-ups work
            if call["name"] == "get_trip" and "error" not in result:
                db.hset(session_key, "trip_id", json.loads(result)["trip_id"])

    return facts, calls


# step 8: request structures
class TripCreate(BaseModel):
    employee_id: str = Field(pattern=r"^EMP\d+$", examples=["EMP104"])
    destination: str = Field(min_length=2, max_length=100)
    start_date: date
    end_date: date
    purpose: str = Field(min_length=2, max_length=200)

    @model_validator(mode="after")
    def check_dates(self):
        if self.start_date < date.today():
            raise ValueError("start_date cannot be in the past")
        if self.end_date < self.start_date:
            raise ValueError("end_date must be on or after start_date")
        return self


class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    session_id: UUID | None = None
    employee_id: str | None = Field(default=None, pattern=r"^EMP\d+$")
    trip_id: int | None = None


# step 9: trip apis
@app.post("/trips", status_code=201)
def create_trip(trip: TripCreate):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.execute(
            "insert into trips (employee_id, destination, start_date, end_date, purpose) values (?, ?, ?, ?, ?)",
            (trip.employee_id, trip.destination, trip.start_date.isoformat(),
             trip.end_date.isoformat(), trip.purpose)
        )
    return fetch_trip(cursor.lastrowid)


@app.get("/trips/{trip_id}")
def get_trip_by_id(trip_id: int):
    trip = fetch_trip(trip_id)
    if not trip:
        raise HTTPException(status_code=404, detail=f"trip {trip_id} not found")
    return trip


# step 10: chat api
@app.post("/chat")
def chat(request: ChatRequest):

    session_id = str(request.session_id or uuid4())

    history_key = f"travel:{session_id}:history"
    context_key = f"travel:{session_id}:context"

    # save employee and trip in the session context
    if request.employee_id:
        db.hset(context_key, "employee_id", request.employee_id)
    if request.trip_id:
        db.hset(context_key, "trip_id", request.trip_id)

    context = db.hgetall(context_key)

    # load recent conversation from redis
    history = []
    for item in db.lrange(history_key, -MAX_HISTORY, -1):
        message = json.loads(item)
        history.append(HumanMessage(message["message"]) if message["role"] == "user" else AIMessage(message["message"]))

    try:
        # stage one: tools fetch trip and weather facts
        facts, calls = gather_facts(request.question, history, context, context_key)

        # stage two: compose the advisory from the facts
        answer = advice_chain.invoke({
            "today": date.today().isoformat(),
            "history": history,
            "question": request.question,
            "facts": "\n".join(facts) or "no tools were called this turn. use facts from earlier in the conversation if present, otherwise say the data is not available",
        })
    except Exception as error:
        raise HTTPException(status_code=502, detail=f"llm request failed: {error}")

    # store chat history in redis
    with db.pipeline() as pipe:
        pipe.rpush(
            history_key,
            json.dumps({"role": "user", "message": request.question}),
            json.dumps({"role": "assistant", "message": answer})
        )
        pipe.ltrim(history_key, -MAX_HISTORY, -1)
        pipe.expire(history_key, SESSION_TTL)
        pipe.expire(context_key, SESSION_TTL)
        pipe.execute()

    return {
        "session_id": session_id,
        "answer": answer,
        "tools_used": calls
    }


# step 11: retrieve redis chat history
@app.get("/history/{session_id}")
def get_history(session_id: UUID):

    history_key = f"travel:{session_id}:history"

    messages = db.lrange(history_key, 0, -1)

    return {
        "session_id": str(session_id),
        "messages": [json.loads(message) for message in messages]
    }
