# Travel Weather Advisory Assistant

A FastAPI service that saves business trips in SQLite, gets live forecasts from Open-Meteo, and gives short travel advice using LangChain with a free OpenRouter model. Redis keeps recent conversation per session so follow-up questions work.

## How it works

1. `POST /chat` receives a question and a session ID.
2. Stage 1: the model calls tools to fetch facts (`get_trip`, `find_employee_trips`, `get_weather_forecast`).
3. Stage 2: an advisory chain writes the answer only from those facts and the conversation history.
4. The question and answer are saved in Redis for that session (last 5 exchanges, 1 hour expiry).

Missing destinations, dates outside the 16 day forecast window, past dates and API failures are returned as errors, and the assistant says the data is not available instead of guessing.

## Files

- `main.py` - API, tools, LangChain stages, Redis memory
- `init_db.py` - SQLite schema and sample trips
- `.env.example` - configuration names

## Setup

1. Install dependencies:
   ```
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Copy `.env.example` to `.env` and fill in the values:
   ```
   OPENROUTER_API_KEY=your-key
   OPENROUTER_MODEL=nvidia/nemotron-3.5-super-vl:free
   OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
   REDIS_URL=redis://localhost:6379/0
   SQLITE_PATH=trips.db
   ```
   Any free OpenRouter model that supports tool calling can be used. If you get a 429 error, the free model is rate limited, so try another one.
3. Start Redis (for example `docker run -p 6379:6379 redis` or a local Redis/Memurai install).
4. Create the database with sample trips:
   ```
   python init_db.py
   ```
   This adds trips for EMP104 (Jaipur, in 3 days), EMP205 (London, in 6 days) and EMP310 (Tokyo, in 40 days, outside the forecast window).

## Run

```
uvicorn main:app --reload
```

Open http://127.0.0.1:8000/docs to test with Swagger.

## Sample requests

Create a trip (use dates within the next 16 days):
```
POST /trips
{"employee_id": "EMP104", "destination": "Jaipur", "start_date": "2026-11-19", "end_date": "2026-11-21", "purpose": "Client meeting"}
```

Get a trip:
```
GET /trips/1
```

Ask about the weather (the response includes a `session_id` and the tools used):
```
POST /chat
{"question": "What weather should I expect for my Jaipur trip?", "employee_id": "EMP104"}
```

Follow-up in the same session, without repeating the destination:
```
POST /chat
{"question": "Should I pack an umbrella and light jacket?", "session_id": "<session_id from previous reply>"}
```

Failure case (trip outside the forecast window):
```
POST /chat
{"question": "What weather should I expect for my trip?", "employee_id": "EMP310"}
```

Invalid input (end date before start date returns 422):
```
POST /trips
{"employee_id": "EMP104", "destination": "Jaipur", "start_date": "2026-11-21", "end_date": "2026-11-19", "purpose": "Client meeting"}
```

View session history:
```
GET /history/<session_id>
```

Weather data by Open-Meteo (https://open-meteo.com), free for non-commercial use.
