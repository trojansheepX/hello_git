
import os
import sqlite3
from datetime import date, timedelta

from dotenv import load_dotenv

load_dotenv()

DB_PATH = os.getenv("SQLITE_PATH", "trips.db")

SCHEMA = """
create table if not exists trips (
    trip_id integer primary key autoincrement,
    employee_id text not null,
    destination text not null,
    start_date text not null,
    end_date text not null,
    purpose text not null,
    status text not null default 'planned',
    created_at text not null default current_timestamp
)
"""


# create the trips table if it does not exist
def create_schema():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(SCHEMA)


# insert a few sample trips with dates relative to today
def seed_samples():
    today = date.today()
    samples = [
        ("EMP104", "Jaipur", today + timedelta(days=3), today + timedelta(days=5), "Client meeting"),
        ("EMP205", "London", today + timedelta(days=6), today + timedelta(days=9), "Quarterly review"),
        ("EMP310", "Tokyo", today + timedelta(days=40), today + timedelta(days=44), "Conference"),
    ]
    with sqlite3.connect(DB_PATH) as conn:
        conn.executemany(
            "insert into trips (employee_id, destination, start_date, end_date, purpose) values (?, ?, ?, ?, ?)",
            [(e, d, s.isoformat(), en.isoformat(), p) for e, d, s, en, p in samples]
        )


if __name__ == "__main__":
    create_schema()
    seed_samples()
    print(f"schema created and sample trips added to {DB_PATH}")
